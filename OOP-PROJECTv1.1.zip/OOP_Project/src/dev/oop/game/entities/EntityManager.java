package dev.oop.game.entities;

/**
* <h1>OOP_PROJECT</h1>
*
*This is a game where the user will get to play
*as a character and fight enemies, collect power ups,
*and collect golden tokens!
*
* @author Nick Mason j.r
* @version 1.0
* @since 2019-10-11
*/


import java.awt.Graphics;
import java.util.ArrayList;

import dev.oop.game.Handler;
import dev.oop.game.Characters.Knight;
import dev.oop.game.Characters.PurpleSkull;

public class EntityManager 
{
	private Handler handler;
	private Knight knight;
	private PurpleSkull ps;
;
	private ArrayList<Entity> entities;
	
	public EntityManager(Handler handler, Knight knight)
	{
		this.handler = handler;
		this.knight = knight;
		ps = new PurpleSkull(handler, 450,335, 80, 80);

		entities= new ArrayList<Entity>();
	addEntity(knight);
	addEntity(ps);

		
	}
	
	public void tick()
	{
		/*This method will be used to tick
		 * every entity in the array list
		 */
		for(int x =0; x < entities.size(); x++)
		{
			Entity entity = entities.get(x);
			entity.tick();
		}
		
		

	}
	
	public void render(Graphics graphic)
	{
		
		/*This method will serve to render 
		 * very entity to the screen.
		 */
		for(Entity entity : entities)
		{
			entity.render(graphic);	
		}
	
	}
	
	public void addEntity(Entity entity)
	{
		/*This method will serve to
		 * add an entity to the array list
		 */
		entities.add(entity);
	}

	public Handler getHandler() {
		return handler;
	}

	public void setHandler(Handler handler) {
		this.handler = handler;
	}

	public ArrayList<Entity> getEntities() 
	{
		/*This method will be used to
		 * return the arraList of entities
		 */
		return entities;
	}

	public void setEntities(ArrayList<Entity> entities) {
		this.entities = entities;
	}

	public Knight getKnight() {
		return knight;
	}

	public void setKnight(Knight knight) {
		this.knight = knight;
	}
}
