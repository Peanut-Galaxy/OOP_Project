package dev.oop.game.Characters;


import java.awt.Color;

/**
* <h1>OOP_PROJECT</h1>
*
*This is a game where the user will get to play
*as a character and fight enemies, collect power ups,
*and collect golden tokens!
*
* @author Nick Mason j.r
* @version 1.0
* @since 2019-10-11
*/

import java.awt.Graphics;

import dev.oop.game.Handler;
import dev.oop.game.Characters.Enemy.mvThread;
import dev.oop.game.entities.Entity;
import dev.oop.game.gfx.Animation;
import dev.oop.game.gfx.Assets;
import dev.oop.game.tile.Tiles;

public class PurpleSkull extends Enemy
{
	
	private Animation moveR;
	private boolean movingRight = true;
	

	public PurpleSkull(Handler handler, float x, float y, int width, int height)
	{
		super(handler, x, y, width, height);
		
		bounds.x = 10;
		bounds.y = 10;
		bounds.width = 57;
		bounds.height = 60;
	
		moveR = new Animation(150, Assets.psRight);
	}

	@Override
	public void tick() 
	{
		moveR.tick();
	//	move();
		moveBounds();
	}
	
	public void collisionWithCharacter()
	{
		
	 

	}

	@Override
	public void render(Graphics graphic) 
	{
		graphic.drawImage(moveR.getCurrentFrame(),(int) (x- handler.getGameCamera().getxOffSet()), (int) (y - handler.getGameCamera().getyOffSet()), width, height, null);
	//	graphic.setColor(Color.red);
	//	graphic.fillRect((int) (x+bounds.x-handler.getGameCamera().getxOffSet()), (int) (y+bounds.y-handler.getGameCamera().getyOffSet()), bounds.width, bounds.height);
	}
	
	public  void moveBounds()
	{
		int tx = (int) (x + xMove + bounds.x + bounds.width) / Tiles.TILE_WIDTH;
		int tx2 = (int) (x + xMove + bounds.x) / Tiles.TILE_WIDTH;
		

			
			if(isMovingRight())
			{
		if(!collision(tx, (int)(y+bounds.y) / Tiles.TILE_HEIGHT) && !collision(tx, (int)(y+bounds.y + bounds.height) / Tiles.TILE_HEIGHT))
		{
			x+=xMove;
		}
		else 
			movingRight = false;
		
			}
			
			
		if(!isMovingRight())
		{
		
			if(!collision(tx2, (int)(y+bounds.y) / Tiles.TILE_HEIGHT) && !collision(tx2, (int)(y+bounds.y + bounds.height) / Tiles.TILE_HEIGHT))
			{
				
				x-=xMove;
			
			}
		else
			
			movingRight = true;
		}
		
		
		
		
	
		
		

	}
	


	private boolean isMovingRight() 
	{
		return movingRight;
	}

	private void setMovingRight(boolean movingRight) {
		this.movingRight = movingRight;
	}

	public void move()
	{
		x+= xMove;
		if(mvStart == false)
		{
		
			mvStart = true;
			new Thread(new mvThread()).start();
		}
		
	}

	
	public class mvThread implements Runnable
	{

		@Override
		public void run() {
			while(true)
			{
			try {
				xMove = speed;
				Thread.sleep(7500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
			try 
			{
				xMove = -speed;
				Thread.sleep(7500);
			} 
			catch (InterruptedException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		  }
		}
		
	}
	

}
