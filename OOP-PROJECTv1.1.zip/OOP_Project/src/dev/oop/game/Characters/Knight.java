package dev.oop.game.Characters;


/**
* <h1>OOP_PROJECT</h1>
*
*This is a game where the user will get to play
*as a character and fight enemies, collect power ups,
*and collect golden tokens!
*
* @author Nick Mason j.r
* @version 1.0
* @since 2019-10-11
*/

import java.awt.Color;
import java.awt.Graphics;

import dev.oop.game.Game;
import dev.oop.game.Handler;
import dev.oop.game.entities.Entity;
import dev.oop.game.gfx.Animation;
import dev.oop.game.gfx.Assets;
import dev.oop.game.tile.Tiles;
import dev.oop.game.world.World;

public class Knight extends Character
{
	

	private Animation moveRight;
	private Animation moveLeft;
	private Animation jumping;
	private Animation hud;
	private Animation dmg;
	private Animation attack;
	private boolean KO;
	private boolean attacking;
	private boolean takingDamage;
	


	private boolean isFacingRight;
	private boolean animating = false;
	

	public Knight(Handler handler, float x, float y)
	{
		/*This method will serve as the
		 * constructor for the knight
		 * class
		 */
		super(handler, x, y, Character.DEFAULT_CHAR_WIDTH, Character.DEFAULT_CHAR_HEIGHT);
		
		bounds.x = 10;
		
		bounds.y = 19;
		
		bounds.height = 40;
		bounds.width = 40;
		
		takingDamage = false;
		attacking = false;
		KO = false;
		moveRight = new Animation(100, Assets.knight_Right);
		moveLeft = new Animation(100, Assets.knight_Left);
		jumping = new Animation(100, Assets.jump);
		hud = new Animation(500, Assets.healthBar);
		dmg = new Animation(200, Assets.dmg);
		attack = new Animation(100,Assets.knightAttack);
	}

	private boolean isAnimating() {
		return animating;
	}

	private void setAnimating(boolean isAnimating) {
		this.animating = animating;
	}

	@Override
	public void tick() 
	{
		healthCheck();
		getInput();
		moveRight.tick();
		moveLeft.tick();
		jumping.tick();
		move(); 
	    handler.getGameCamera().centerOnChar(this);
	}
	
	@Override
	public void render(Graphics graphic) 
	{
		
		if(isAnimating() && !isAttacking())
		{
			graphic.drawImage(jumping.getCurrentFrame(),(int) (x-handler.getGameCamera().getxOffSet()), (int) (y-handler.getGameCamera().getyOffSet()), width, height, null);
		}
		
		if(isAttacking() && !isAnimating())
		{
			graphic.drawImage(attack.getCurrentFrame(),(int) (x-handler.getGameCamera().getxOffSet()), (int) (y-handler.getGameCamera().getyOffSet()), width, height, null);
		}
		
		else if((xMove > 0) && !isAttacking())
		{
			if(isJumping == true && !isAnimating())
			{
				graphic.drawImage(jumping.getCurrentFrame(),(int) (x-handler.getGameCamera().getxOffSet()), (int) (y-handler.getGameCamera().getyOffSet()), width, height, null);
			}
			else
	         graphic.drawImage(moveRight.getCurrentFrame(),(int) (x-handler.getGameCamera().getxOffSet()), (int) (y-handler.getGameCamera().getyOffSet()), width, height, null);
		}
		else  if((xMove < 0) && !isAttacking())
		{
			if(isJumping == true && !isAnimating())
			{
				graphic.drawImage(jumping.getCurrentFrame(),(int) (x-handler.getGameCamera().getxOffSet()), (int) (y-handler.getGameCamera().getyOffSet()), width, height, null);
			}
			else
			graphic.drawImage(moveLeft.getCurrentFrame(),(int) (x-handler.getGameCamera().getxOffSet()), (int) (y-handler.getGameCamera().getyOffSet()), width, height, null);
		}
		
		else if(isJumping == true && !isAnimating())
		{
			graphic.drawImage(jumping.getCurrentFrame(),(int) (x-handler.getGameCamera().getxOffSet()), (int) (y-handler.getGameCamera().getyOffSet()), width, height, null);
		}
		


		
		else if(isFacingRight == true && (!isAnimating() || !isAttacking())) 
		{
			graphic.drawImage(Assets.knightRightStanding,(int) (x-handler.getGameCamera().getxOffSet()), (int) (y-handler.getGameCamera().getyOffSet()), width, height, null);
		}
		
		else if(isFacingRight == false)
		{
			graphic.drawImage(Assets.knightLeftStanding,(int) (x-handler.getGameCamera().getxOffSet()), (int) (y-handler.getGameCamera().getyOffSet()), width, height, null);
		}

		if((checkEntityCollisions(xMove,0f) || checkEntityCollisions(0f,yMove)))
		{
			graphic.drawImage(dmg.getCurrentFrame(),(int) (x-handler.getGameCamera().getxOffSet()), (int) (y-handler.getGameCamera().getyOffSet()), width, height, null);
			

			if(!isTakingDamage())
			{
			new Thread(new takingDmg()).start();
			}
		}
		if(getHealth() > 182 && getHealth() < 201)
		{
		graphic.drawImage(hud.setIndex(0),(int) (x-handler.getGameCamera().getxOffSet()), (int) ((y-handler.getGameCamera().getyOffSet()) -20), 100, 10, null);
		}
		else if(getHealth() > 150 && getHealth() < 181)
		{
			graphic.drawImage(hud.setIndex(1),(int) (x-handler.getGameCamera().getxOffSet()), (int) ((y-handler.getGameCamera().getyOffSet()) -20), 100, 10, null);
		}
		
		else if(getHealth() > 120 && getHealth() < 150)
		{
			graphic.drawImage(hud.setIndex(2),(int) (x-handler.getGameCamera().getxOffSet()), (int) ((y-handler.getGameCamera().getyOffSet()) -20), 100, 10, null);
		}
		
		else if(getHealth() > 100 && getHealth() < 120)
		{
			graphic.drawImage(hud.setIndex(3),(int) (x-handler.getGameCamera().getxOffSet()), (int) ((y-handler.getGameCamera().getyOffSet()) -20), 100, 10, null);
		}
		
		else if(getHealth() > 60 && getHealth() < 100)
		{
			graphic.drawImage(hud.setIndex(4),(int) (x-handler.getGameCamera().getxOffSet()), (int) ((y-handler.getGameCamera().getyOffSet()) -20), 100, 10, null);
		}
		
		else if(getHealth() > 40 && getHealth() < 60)
		{
			graphic.drawImage(hud.setIndex(5),(int) (x-handler.getGameCamera().getxOffSet()), (int) ((y-handler.getGameCamera().getyOffSet()) -20), 100, 10, null);
		}
		
		else if(getHealth() > 10 && getHealth() < 30)
		{
			graphic.drawImage(hud.setIndex(6),(int) (x-handler.getGameCamera().getxOffSet()), (int) ((y-handler.getGameCamera().getyOffSet()) -20), 100, 10, null);
		}
		
		else
		{
			health = 0;
		graphic.drawImage(hud.setIndex(7),(int) (x-handler.getGameCamera().getxOffSet()), (int) ((y-handler.getGameCamera().getyOffSet()) -20), 100, 10, null);
		}

		
		//graphic.setColor(Color.blue);
	//	graphic.fillRect((int) (x+bounds.x-handler.getGameCamera().getxOffSet()), (int) (y+bounds.y-handler.getGameCamera().getyOffSet()), bounds.width, bounds.height);
	}
	
	
	
	
	private void healthCheck()
	{
		
		/*This method will serve to check
		 * for collisions with enemy entities
		 * and update the characters health 
		 * accordingly. It will also start a
		 * thread that will set a timer for
		 * a taking dmg buffer
		 */
		if(checkEntityCollisions(xMove, 0f) || checkEntityCollisions(0f,yMove))
		{
			if(!isTakingDamage())
			{
			
			if(health <= 0)
			{
				health = 0;
				
			}
			else
			health -=13;
			}
			
		}
		
	}
	
	protected void death()
	{
		KO = true;
	}
	
	protected boolean isKO()
	{
		return KO;
	}
	
	private boolean isTakingDamage() 
	{
		return takingDamage;
	}

	private void setTakingDamage(boolean takingDamage) 
	{
		this.takingDamage = takingDamage;
	}

	
	private synchronized void getInput()
	{
		xMove = 0;
		
		if(handler.getKeyManager().space)
		{

			if(!isAttacking())
			{
				attacking = true;
				new Thread(new attackingT()).start();
			}
		}
		
		
		if(handler.getKeyManager().up)
		{

if(isJumping == false)
{
        new Thread(new thread()).start();
        if(!isAnimating())
        {
        	new Thread(new animationThread()).start();
        }
}
		}
		
		if(handler.getKeyManager().down)
		{
			//yMove = +speed;
		}
		
		if(handler.getKeyManager().left)
		{
			isFacingRight = false;
			xMove = -speed;
		}
		
		if(handler.getKeyManager().right)
		{
			isFacingRight = true;
			xMove = +speed;
		}
		
	}

public class thread implements Runnable
{
	@Override
	public void run()
	{
		try 
		{
			isJumping = true;
			yMove = -jumpStrength;
			Thread.sleep(jumpTime);
			yMove = jumpStrength;

		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}

public class animationThread implements Runnable
{
	@Override
	public void run()
	{
		try
		{
			animating = true;
			Thread.sleep(580);
			animating = false;
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}

public class takingDmg implements Runnable
{
	@Override
	public void run()
	{
	
		try {
			takingDamage = true;
			
			Thread.sleep(200);
			takingDamage = false;
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
	}
}

public class attackingT implements Runnable
{
	@Override
	public void run()
	{
		try {
		
			Thread.sleep(1000);
			attacking = false;
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}


private boolean isAttacking() {
	return attacking;
}

private void setAttacking(boolean isAttacking) {
	this.attacking = attacking;
}

 
}
