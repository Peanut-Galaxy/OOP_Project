package dev.oop.interf;



/**
* <h1>OOP_PROJECT</h1>
*
*This is a game where the user will get to play
*as a character and fight enemies, collect power ups,
*and collect golden tokens!
*
* @author Nick Mason j.r
* @version 1.0
* @since 2019-10-11
*/



import java.awt.Canvas;
import java.awt.Dimension;

import javax.swing.JFrame;

public class UI 
{
	private JFrame frame;
	private Canvas canvas;
	private String title;
	private int width;
	private int height;
	
	public UI(String title, int width, int height)
	{
		/*This method will serve as a 
		 * constructor for the method 
		 * UI
		 */
		this.title = title;
		this.width = width;
		this.height = height;
		
		createUI();
	}
	
	private void createUI()
	{
		
		/*This method will serve to intitialize
		 * the UI and all its components
		 * 
		 */
		frame = new JFrame(title);
		frame.setSize(width,height);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(false);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
		
		canvas = new Canvas();
		canvas.setPreferredSize(new Dimension(width, height));
		canvas.setMaximumSize(new Dimension(width, height));
		canvas.setMinimumSize(new Dimension(width, height));
		canvas.setFocusable(false);
		
		frame.add(canvas);
		frame.pack();
	}
	
	public Canvas getCanvas()
	{
		/*This method will be used to
		 * return the canvas
		 */
		return canvas;
	} 
	
	public JFrame getFrame()
	{
		/*This method will
		 *be used to return the
		 *frame
		 */
		
		return frame;
	}
	

	
	
	
}
